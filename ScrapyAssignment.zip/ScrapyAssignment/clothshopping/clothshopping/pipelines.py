# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
import sqlite3
from itemadapter import ItemAdapter


class ClothshoppingPipeline(object):
    def __init__(self):
        self.create_connection()
        self.create_table()
        
    def create_connection(self):
        self.con = sqlite3.connect('Clothdatabase.db')
        self.cur = self.con.cursor()
    
    def create_table(self):
       # self.cur.execute(""" DROP TABLE IF EXISTS clothdb""")
        self.cur.execute(""" CREATE TABLE IF NOT EXISTS cloth_db(
            name TEXT,
            real_price TEXT,
            discount_price TEXT
            )""")
    
    def process_item(self, item, spider):
        self.store_db(item)
        return item
   
    def store_db(self,item):
        self.cur.execute("""INSERT INTO cloth_db VALUES (?,?,?) """,
                         (str(item['name']),str(item['real_price']),str(item['discount_price'])))
        self.con.commit()
        return item
        
       
