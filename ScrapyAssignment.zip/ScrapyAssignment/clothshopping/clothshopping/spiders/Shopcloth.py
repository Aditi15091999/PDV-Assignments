# -*- coding: utf-8 -*-
"""
Created on Sat Jan 29 01:19:35 2022

@author: aditi
"""

import scrapy

from ..items import ClothshoppingItem

class ShopclothSpider(scrapy.Spider):
    
    name='Clothes'
    start_urls=['https://shekouwoman.com/collections/home']
    
    def parse(self, response):
        #title=response.css('title::text').extract()
        #yield{'titleset':title}
        items=ClothshoppingItem()
        
        for products in response.css('div.product--details-container'):
            
            items['name']=products.css('p::text').get().strip()
            items['real_price']=products.css('span.product--compare-price.money::text').get()
            items['discount_price']=products.css('span.product--price.money::text').get().strip()
            
            yield items
           
            
        '''yield {
                'name': products.css('p::text').extract(),
                'real_price':products.css('span.product--compare-price.money::text').extract(),
                'discount_price':products.css('span.product--price.money::text').get().split()
                    }
            
        next_page=response.css('a.pagination--link')[2].attrib['href']
        if next_page is not None:
           yield response.follow(next_page, callback = self.parse)'''
